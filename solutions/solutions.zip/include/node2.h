#pragma once

#include <ros/ros.h>
#include <ros/console.h>
#include <ros/timer.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Twist.h>

class Node2
{
public:
  Node2();

private:
  ros::NodeHandle nodeHandle_, privateNodeHandle_;
  ros::Subscriber adderOutSub_, counterOutSub_;
  ros::Publisher subtractOutPub_, multiplyOutPub_;
  ros::Timer countTimer_;

  std_msgs::Float64 adderOutMsg_;
  geometry_msgs::Twist twistMsg_;

  double publishingFreq_;
  double substractorValue_, multiplyFactor_;
  int counterOutVal_;

  void adderOutCallback(const std_msgs::Float32::ConstPtr& msg);
  void counterOutCallback(const std_msgs::Int32::ConstPtr& msg);
  void multiplyCounter(const ros::TimerEvent&);
};