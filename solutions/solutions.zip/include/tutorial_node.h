#pragma once
// Put the preprocessor directives and include commands here

// Include files for ROS libraries.
#include <ros/console.h>
#include <ros/ros.h>
#include <ros/timer.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Int32.h>
#include <std_msgs/String.h>

// Include files for C++ libraries
#include <math.h>
#include <algorithm>
#include <chrono>
#include <iostream>
#include <string>

class TutorialNode
{
public:
  TutorialNode();

private:
  // variables for ros interactions
  ros::NodeHandle nodeHandle_, privateNodeHandle_;
  ros::Subscriber countSubscriber_, myNameSubscriber_;
  ros::Publisher countPublisher_, adderPublisher_;
  ros::Timer countTimer_;

  std_msgs::Int32 numberCountMessage_;
  std_msgs::Float32 numberAdderMessage_;

  // variable declaration for member attributes
  double publishingInterval_;
  double numberIncrementer_;
  int numCount_;
  int numResets_;
  std::string myName_;

  // function declaration for member functions
  double doCoolStuff(double num1, double num2);
  void adderCallback(const std_msgs::Float32::ConstPtr& msg);
  void myNameCallback(const std_msgs::String::ConstPtr& msg);
  void publishCount();
  void incrementCount(const ros::TimerEvent&);
};
