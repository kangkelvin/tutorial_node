#include "node2.h"

Node2::Node2() : nodeHandle_(), privateNodeHandle_("~")
{
  // initialize the ros parameters
  privateNodeHandle_.param("publishing_frequency", publishingFreq_, 5.0);
  privateNodeHandle_.param("subtractor_value", substractorValue_, 5.0);
  privateNodeHandle_.param("multiply_factor", multiplyFactor_, 5.6);
  // initalize timers
  countTimer_ = nodeHandle_.createTimer(ros::Duration(1.0 / publishingFreq_), &Node2::multiplyCounter, this);

  /* initialize the publisher and subscriber */
  // topic subscriber
  adderOutSub_ = nodeHandle_.subscribe("/adder_out", 1, &Node2::adderOutCallback, this);
  counterOutSub_ = nodeHandle_.subscribe("/counter_out", 5, &Node2::counterOutCallback, this);
  // topic publisher
  subtractOutPub_ = nodeHandle_.advertise<std_msgs::Float64>("/result/subtract", 1);
  multiplyOutPub_ = nodeHandle_.advertise<geometry_msgs::Twist>("/result/multiply", 1);
}

void Node2::adderOutCallback(const std_msgs::Float32::ConstPtr& msg)
{
  adderOutMsg_.data = msg->data - substractorValue_;
  subtractOutPub_.publish(adderOutMsg_);
}

void Node2::counterOutCallback(const std_msgs::Int32::ConstPtr& msg)
{
  counterOutVal_ = msg->data;
}

void Node2::multiplyCounter(const ros::TimerEvent&)
{
  twistMsg_.linear.x = counterOutVal_ * multiplyFactor_;
  multiplyOutPub_.publish(twistMsg_);
}

/**
 * Main function to initialize the ros node and construct the node class
 */
int main(int argc, char** argv)
{
  ros::init(argc, argv, "Node2");
  Node2 node;
  ros::spin();
  return 0;
}