#include "tutorial_node.h"

TutorialNode::TutorialNode() : nodeHandle_(), privateNodeHandle_("~"), numCount_(0)
{
  // initialize the ros parameters
  privateNodeHandle_.param("publishing_interval", publishingInterval_, 1.0);
  privateNodeHandle_.param("number_incrementer", numberIncrementer_, 3.0);
  // initalize timers
  countTimer_ = nodeHandle_.createTimer(ros::Duration(publishingInterval_), &TutorialNode::incrementCount, this);

  /* initialize the publisher and subscriber */
  // topic subscriber
  countSubscriber_ = nodeHandle_.subscribe("/adder_in", 1, &TutorialNode::adderCallback, this);
  myNameSubscriber_ = nodeHandle_.subscribe("/my_name", 5, &TutorialNode::myNameCallback, this);
  // topic publisher
  countPublisher_ = nodeHandle_.advertise<std_msgs::Int32>("/counter_out", 1);
  adderPublisher_ = nodeHandle_.advertise<std_msgs::Float32>("/adder_out", 1);
}

// Example of a cool algorithm that you will run
double TutorialNode::doCoolStuff(double num1, double num2)
{
  num1 += num2;  // adds the subscribed data
  ROS_INFO("The sum is = [%f]", num1);

  return num1;
}

/**
 * This callback method is called when the node recieves a count data
 * @param &msg is the timer action that triggers the event
 */
void TutorialNode::adderCallback(const std_msgs::Float32::ConstPtr& msg)
{
  double numberReceived = msg->data;  // extracts the data from the message

  ROS_INFO("The number recieved is %f", numberReceived);
  ROS_INFO("Adding the number recieved by %f", numberIncrementer_);

  double output = doCoolStuff(numberReceived, numberIncrementer_);

  numberAdderMessage_.data = output;             // puts the data to the message.
  adderPublisher_.publish(numberAdderMessage_);  // publishes the message to the topic
}

/**
 * This method publishes the count
 */
void TutorialNode::publishCount()
{
  ROS_INFO("Publishing counter... [%d]", numCount_);
  numberCountMessage_.data = numCount_;          // inserts the data to the ros message
  countPublisher_.publish(numberCountMessage_);  // the publisher publishes the message and its contents.
}

/**
 * This method increments the count by 1 every time the timer triggers an event
 */
void TutorialNode::incrementCount(const ros::TimerEvent&)
{
  numCount_ += 1;
  publishCount();
}

/**
 * This method reads the topic and store it to a class member variable
 */
void TutorialNode::myNameCallback(const std_msgs::String::ConstPtr& msg)
{
  myName_ = msg->data;
}

/**
 * Main function to initialize the ros node and construct the node class
 */
int main(int argc, char** argv)
{
  ros::init(argc, argv, "tutorial_node");
  TutorialNode node;
  ros::spin();
  return 0;
}